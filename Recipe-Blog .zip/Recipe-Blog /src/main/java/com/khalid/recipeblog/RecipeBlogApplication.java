package com.khalid.recipeblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeBlogApplication.class, args);
	}

}
