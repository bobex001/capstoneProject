package com.khalid.recipeblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
